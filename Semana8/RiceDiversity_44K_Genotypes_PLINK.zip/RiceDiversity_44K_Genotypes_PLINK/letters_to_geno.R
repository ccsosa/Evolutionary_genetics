require(readxl)

geno_to <- as.data.frame(readxl::read_excel("D:/GWAS_TEST/Geno.xlsx"))
unique(geno_to[,2])
geno_to[geno_to=="NC"] <- NA
geno_to[geno_to=="AA"] <- 2
geno_to[geno_to=="BB"] <- 2
geno_to[geno_to=="AB"] <- 1

row.names(geno_to) <- geno_to[,1]
write.table(geno_to[,-1],"D:/GWAS_TEST/Geno.txt",row.names = T,col.names = F,sep = "\t",quote = F)
